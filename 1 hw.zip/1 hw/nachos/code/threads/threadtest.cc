#include "kernel.h"
#include "main.h"
#include "thread.h"
void printA(int i) {
	cout << "aaaaaaaaaaaa" << endl;
	kernel->currentThread->Yield();

}
void SimpleThread(int which)
{
    int num;
    
    for (num = 0; num < 5; num++) {
        printf("*** thread %d looped %d times\n", which, num);
        kernel->currentThread->Yield();
    }
	kernel->currentThread->Finish();

	

}

void ThreadTest()
{
    Thread *t = new Thread("forked thread");
    t->Fork((VoidFunctionPtr) SimpleThread, (void *) 1);

	Thread *aa = new Thread("aaaa");
	aa->Fork((VoidFunctionPtr)printA, (void *)1);
    //SimpleThread(0);
}
