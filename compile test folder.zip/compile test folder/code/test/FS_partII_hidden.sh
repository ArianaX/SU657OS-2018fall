../build.linux/nachos -f
../build.linux/nachos -cp nachos.html /nachos
../build.linux/nachos -p /nachos

