﻿#include "kernel.h"
#include "main.h"
#include "thread.h"
#include "../hw3/Request.h"
#include "../lib/list.h"
#include "../machine/interrupt.h"
Bitmap* flightSeat =new Bitmap(20);
List<Request*>* grantList = new List<Request*>();
List<Request*>* ungrantList = new List<Request*>();
List<Thread*> * threadList = new List<Thread*>();
int countThread = 1;

void afterThreadPrint() {
	cout << "~~~~~~~~~~after simulating~~~~~output 4~~~~~~~~~~~~~~~~~~" << endl;
	cout << "~~~~~print out all Req# in Ungranted list~~~~~~~~~~~~~" << endl;

	ListIterator<Request*> itR = ListIterator<Request*>(ungrantList);
	while (!itR.IsDone()) {
		cout << "Req#" << itR.Item()->getId() << endl;
		itR.Next();
	}
}
void printRequest(Request* rr) {
	//double i = rr.getPersonNum / 20;
	cout << "Req#:" << rr->getId() << "\t number of seats(person number):" << rr->getPersonNum() << "\t Departure City:" << rr->getDepCity() << "\t Destination:" << rr->getDesCity() << endl;
}

void PrintRSeat(Request* rr) {
	cout << "Req#:" << rr->getId();//<< "\tPerson Number:" << rr.getPersonNum
	Bitmap* temp = rr->getSeat();
	cout << "\t Seat#:";
	temp->Print();//seat assignment

	cout << "\t Now Available number:" << flightSeat->NumClear() << endl;

}
void applyPrintAllRequest(Request* rr) {
	ListIterator<Request*> itR = ListIterator<Request*>(grantList);
	while (!itR.IsDone()) {
		cout << "Req#: " << itR.Item()->getId() << endl;
		itR.Next();
	}
	cout << "-----------------------------------" << endl;
	cout <<"Now Occupancy:" << (double)(20-flightSeat->NumClear()) / 20 << endl;
}
void reservationImpl(int city) {
	kernel->interrupt->SetLevel(IntOff);
	
	Request* rr = new Request();
	rr->setId(countThread);
	countThread++;
	rr->setDepCity(city);
	rr->setDesCity();
	rr->setPersonNum();
	//print the request information:
	cout << "------Output 3------------~~~~~~~~~~~~~~~~-------------------------" << endl;
	cout << "1. create a new request:" << endl;
	printRequest(rr);
	if (flightSeat->NumClear() >= rr->getPersonNum()) {

		grantList->Append(rr);  //add to the end of list;
		threadList->Append(kernel->currentThread);//save the current thread;

		cout << "2. can assign seats:" << endl;
		cout << "\t Available number:" << flightSeat->NumClear() << endl;
		rr->setSeat(flightSeat);
		PrintRSeat(rr);

		cout << "-------------------------------------" << endl;
		//my
		//kernel->currentThread->Yield();
		kernel->currentThread->Sleep(false);//havent finished

	}
	else {
		cout << "2. cannot assign the seats, discard from list:" << endl;
		cout << "Req#:" << rr->getId() << "\t Person Number:" << rr->getPersonNum() << "\t Departure City:" << rr->getDepCity() << "\t Destination:" << rr->getDesCity() << endl;
		cout << "..........................................." << endl;

		ungrantList->Append(rr);
		kernel->currentThread->Finish();
	}


	//release seat:
	//delocate the bitmap here:
	//output 1: get off
	Bitmap* temp = rr->getSeat();
	cout << "------Output 1-------If it is a destination city -----" << endl;
	cout << "This is a destination, passenger get off: Req#:" << rr->getId() << "\t Seat# :";
	temp->Print();
	//delete in global bitmap
	for (int i = 0; i < rr->getPersonNum(); i++) {
		flightSeat->Clear(temp->FindAndClear());
	}
	cout << "\t After getting off: Available number:" << flightSeat->NumClear() << endl;

	grantList->Remove(rr);//delete request
	threadList->Remove(kernel->currentThread);
	//all passengers get off: output 2
	//print out IDs of all the requests currently on the plane and occupancy rate of seats.
	cout << "------Output 2------all the requests currently on the plane ---------" << endl;
	applyPrintAllRequest(rr);

	if (threadList->IsEmpty()) {
		afterThreadPrint();
	}

	kernel->currentThread->Finish();
	
}


void flightThreadImpl(int a) {
	//focus on 5 cities
	for (int cc = 1; cc <= 5; cc++) {//cc=1-----dest is A
		kernel->interrupt->SetLevel(IntOff);
		cout << "~~~~~~~~~~~~~~~~~~~~~~~~~" << endl;
		//cout << "Right now, we are in City:" << cc << endl;
		if (cc > 1 ) {
			//check whether is the dest
			ListIterator<Request*> itR = ListIterator<Request*>(grantList);
			ListIterator<Thread*> itT = ListIterator<Thread*>(threadList);
			while (!itR.IsDone()) {
				if (itR.Item()->getDesCity() == cc) {
					kernel->scheduler->ReadyToRun(itT.Item());
				}
				itR.Next();
				itT.Next();
			}
		}
		if (cc != 5) {
			for (int i = 1; i <= 5; i++) {
				Thread *t = new Thread("Reservation thread");
				t->Fork((VoidFunctionPtr)reservationImpl, (void*)cc);
			}
			kernel->currentThread->Yield();
		}
	}
	

	kernel->currentThread->Finish();


}


void ThreadTest()
{
	Thread *t = new Thread("Flight thread");
	t->Fork((VoidFunctionPtr)flightThreadImpl, (void *)1);//(VoidFunctionPtr)

	
}
