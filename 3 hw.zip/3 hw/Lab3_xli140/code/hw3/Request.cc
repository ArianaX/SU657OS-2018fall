#include <stdlib.h>
#include "Request.h"

Request::Request() {
	
}
Request::Request(int id,int city) {
	num_ID = id;
	setDepCity(city);
	setDesCity();
	setPersonNum();
}
Request::~Request() {
	delete seat;
}

bool Request:: isEnough(Bitmap s) {
	if (s.NumClear()>=num_persons)
		return true;
	else
		return false;
}

int Request:: getId()const {
	return num_ID;
}
int Request::getPersonNum()const {
	return num_persons;
}
int Request::getDesCity() const {
	return des_city;
}

int Request::getDepCity()const {
	return dep_city;
}
Bitmap* Request::getSeat()const {
	return seat;
}

void Request::setId(int id) {
	this->num_ID = id;
}
void Request::setPersonNum() {
	this->num_persons = (rand()%5)+1;
}
void Request::setDesCity() {
	if (dep_city != 5)//not E
	{
		des_city = dep_city + ((rand() % (5 - dep_city)) + 1); 
	}
}
void Request::setDepCity(int i) {
	this->dep_city = i;
}

void Request::setSeat(Bitmap* s) {
	//if (isEnough(s) == true)
	{
		int idx;
		for (int i = 0; i < this->num_persons; i++) {
			 idx = s->FindAndSet();//set s
			 seat->Mark(idx);//if bitmap ==1, then the index is the seat number
		}
	}
}


bool Request::operator == (Request p) const {
	if (this->num_ID == p.getId())
		return true;
	else
		return false;
}
