#include<iostream>
using namespace std;

#include "../lib/bitmap.h"
class Request {
private:
	int num_ID;
	int num_persons;//(1-5) randomly
	int des_city;//A-E:(1-5)
	int dep_city;
	Bitmap* seat=new Bitmap(20);
public:
	Request();
	Request(int id,int city);
	~Request();
	bool isEnough(Bitmap s);

	int getId()const;
	int getPersonNum()const;
	int getDesCity()const;
	int getDepCity()const;
	Bitmap* getSeat()const;

	void setId(int id);
	void setPersonNum();
	void setDesCity();
	void setDepCity(int i);
	void setSeat(Bitmap* s);//s.size()>=num_persons

	bool operator == (Request p) const;
};