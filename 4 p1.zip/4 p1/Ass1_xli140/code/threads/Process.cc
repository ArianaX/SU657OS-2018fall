#include "Process.h"
#include "main.h"
#include "../machine/interrupt.h"

// this is put at the top of the execution stack, for detecting stack overflows
const int STACK_FENCEPOSTP = 0xdedbeef;
static int PriCompare(Process* p1, Process* p2)// 5 is the highest priority
{
	if (p1->getPriority() > p2->getPriority())
		return -1;
	else if (p1->getPriority() < p2->getPriority())
		return 1;
	else
		return 0;
}
static void SimpleThread2(int which)
{
	int num;
	cout << "**i am a thread: " << kernel->currentProcess->currentThread->getName()<<" ***** from process:" <<kernel->currentProcess->getName()<< endl;
	kernel->currentProcess->currentThread->Yield();
}

Process::Process(char* name, int p, int thread_n) {//, int thread_n
	this->name = name;
	this->priotity = p;
	this->thread_nums = thread_n;
	this->pid = pid_base;
	pid_base++;
	this->status = P_JUST_CREATED;

	Thread* t = new Thread("default ");
	this->currentThread = t;
	//threadList->Append(t);
	//cout << "p p 40" << endl;
}

Process::~Process() {
	delete PList;
	delete threadList;
	delete currentThread;
	delete scheduler;

}
int Process::getPid() {
	return pid;
}
int Process::getPriority() const {
	return this->priotity;
}
void Process::Fork(VoidFunctionPtr func, void *arg)//Forks off a child process, put current process's thread in the end of list, and create another process kernel ready to run the new child process.
{
	Interrupt *interrupt = kernel->interrupt;
	IntStatus oldLevel;

	DEBUG(dbgThread, "Forking thread: " << name << " f(a): " << (int)func << " " << arg);
	this->currentThread->Fork(this, (VoidFunctionPtr)SimpleThread2, (void*)1);

	for (int num = 0; num < this->getThreadNums(); num++) {//following threads

		Thread* tt = new Thread("thread thread thread");//(char*)('0'+num)
		tt->Fork(this, (VoidFunctionPtr)SimpleThread2, (void*)1);// already readytorun
		//cout << "62 fork " << endl;
		threadList->Append(tt);
	}
	//cout << "p fork 75" << endl;
	this->currentThread = this->scheduler->FindNextThreadToRun();
	//truly run process:
	oldLevel = interrupt->SetLevel(IntOff);

	kernel->pscheduler->ReadyToRunP(this);	
	scheduler->ReadyToRun(this->currentThread);//run thread;
	//cout << "p fork 74" << endl;

	(void)interrupt->SetLevel(oldLevel);

}
void Process::Joint() {//Makes a parent process block until all of the listed child processes have terminated
	ListIterator<Process*> it = ListIterator<Process*>(PList);
	while (!it.IsDone()) {
		if (it.Item()->status == P_BLOCKED) {//update the plist process
			PList->Remove(it.Item());
		}
		it.Next();
	}

	if (PList == NULL) {
		this->Terminate();
	}
	else {
		this->Sleep(false);
		kernel->currentProcess = PList->Front();
	}
}
void Process::Terminate()//Terminates the running process same as thread sleep()
{
	//(void)kernel->interrupt->SetLevel(IntOff);
	Process *nextThread;
	status = P_BLOCKED;//status
	while ((nextThread = kernel->pscheduler->FindNextToRunP()) == NULL) {
		//cout << "p 111" << endl;
		kernel->interrupt->Idle();	// no one to run, wait for an interrupt

	}

									// returns when it's time for us to run
	kernel->pscheduler->RunP(nextThread, TRUE);

	//(void)kernel->interrupt->SetLevel(IntOff);

	
}

void ProcessPrint(Process *t) { t->Print(); }

void Process::Yield()//put current to the end of list
{
	Process *nextProcess;
	//Thread* nextThread;
	IntStatus oldLevel = kernel->interrupt->SetLevel(IntOff);

	ASSERT(this == kernel->currentProcess);

	DEBUG(dbgThread, "Yielding thread: " << name);
	//cout << "p yield 132" << endl;
	nextProcess = kernel->pscheduler->FindNextToRunP();
	if (nextProcess != NULL) {//if have next process,we 
		kernel->pscheduler->ReadyToRunP(this);
		kernel->pscheduler->RunP(nextProcess, FALSE);//????
		//cout << "ttttt" << endl;

	}
	//cout << "ttttt22" << endl;

	(void)kernel->interrupt->SetLevel(oldLevel);
}

void Process::Sleep(bool finishing)
{
	Process *nextThread;

	ASSERT(this == kernel->currentProcess);
	ASSERT(kernel->interrupt->getLevel() == IntOff);

	DEBUG(dbgThread, "Sleeping thread: " << name);

	status = P_BLOCKED;
	while ((nextThread = kernel->pscheduler->FindNextToRunP()) == NULL) {
		//cout << "p 159" << endl;
		kernel->interrupt->Idle();	// no one to run, wait for an interrupt
	}
									// returns when it's time for us to run
	kernel->pscheduler->RunP(nextThread, finishing);
}

void Process::createChildProcess() {//add to child list
	string temp = (string)this->getName() + "--Child";
	Process *pchild = new Process((char*)temp.c_str(), this->getPriority(), this->getThreadNums());
	PList->Append(pchild);
	//pchild->Fork((VoidFunctionPtr)SimpleProcess2, (void *)this->getThreadNums());
}
