// scheduler.cc 
//	Routines to choose the next thread to run, and to dispatch to
//	that thread.
//
// 	These routines assume that interrupts are already disabled.
//	If interrupts are disabled, we can assume mutual exclusion
//	(since we are on a uniprocessor).
//
// 	NOTE: We can't use Locks to provide mutual exclusion here, since
// 	if we needed to wait for a lock, and the lock was busy, we would 
//	end up calling FindNextToRun(), and that would put us in an 
//	infinite loop.
//
// 	Very simple implementation -- no priorities, straight FIFO.
//	Might need to be improved in later assignments.
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

//process
#include "copyright.h"
#include "debug.h"
#include "scheduler.h"
#include "main.h"

//----------------------------------------------------------------------
// Scheduler::Scheduler
// 	Initialize the list of ready but not running threads.
//	Initially, no ready threads.
//----------------------------------------------------------------------
static int PriCompare(Process* p1, Process* p2)// 5 is the highest priority
{
	if (p1->getPriority() > p2->getPriority())
		return -1;
	else if (p1->getPriority() < p2->getPriority())
		return 1;
	else
		return 0;
}
Scheduler::Scheduler()
{
	readyListP = new SortedList<Process*>(PriCompare);
	toBeDestroyedP = NULL;
}

//----------------------------------------------------------------------
// Scheduler::~Scheduler
// 	De-allocate the list of ready threads.
//----------------------------------------------------------------------

Scheduler::~Scheduler()
{ 
    delete readyListP; 
} 

//----------------------------------------------------------------------
// Scheduler::ReadyToRun
// 	Mark a thread as ready, but not running.
//	Put it on the ready list, for later scheduling onto the CPU.
//
//	"thread" is the thread to be put on the ready list.
//----------------------------------------------------------------------

void Scheduler::ReadyToRunP (Process *thread)
{
	//kernel->interrupt->SetLevel(IntOff);//this is coorrect

    ASSERT(kernel->interrupt->getLevel() == IntOff);
    DEBUG(dbgThread, "Putting thread on ready list: " << thread->getName());
    thread->setStatus(P_READY);
    readyListP->Insert(thread);
	//kernel->interrupt->SetLevel(IntOn);//this is coorrect

}

//----------------------------------------------------------------------
// Scheduler::FindNextToRun
// 	Return the next thread to be scheduled onto the CPU.
//	If there are no ready threads, return NULL.
// Side effect:
//	Thread is removed from the ready list.
//----------------------------------------------------------------------

Process * Scheduler::FindNextToRunP()
{
	//kernel->interrupt->SetLevel(IntOff);//this is coorrect

    ASSERT(kernel->interrupt->getLevel() == IntOff);
    if (readyListP->IsEmpty()) {
	return NULL;
    } else {
    	return readyListP->RemoveFront();
    }
	//kernel->interrupt->SetLevel(IntOn);//this is coorrect

}

//----------------------------------------------------------------------
// Scheduler::Run
// 	Dispatch the CPU to nextThread.  Save the state of the old thread,
//	and load the state of the new thread, by calling the machine
//	dependent context switch routine, SWITCH.
//
//      Note: we assume the state of the previously running thread has
//	already been changed from running to blocked or ready (depending).
// Side effect:
//	The global variable kernel->currentThread becomes nextThread.
//
//	"nextThread" is the thread to be put into the CPU.
//	"finishing" is set if the current thread is to be deleted
//		once we're no longer running on its stack
//		(when the next thread starts running)
//----------------------------------------------------------------------

void Scheduler::RunP (Process *nextThread, bool finishing)
{
	
	//kernel->interrupt->SetLevel(IntOn);//this is correct

    Thread *oldThread = kernel->currentProcess->currentThread;
    ASSERT(kernel->interrupt->getLevel() == IntOff);
    if (finishing) {	// mark that we need to delete current thread
        ASSERT(toBeDestroyedP == NULL);//now nothing to be destroyed
		toBeDestroyedP = kernel->currentProcess;
		//kernel->currentProcess->Terminate();//AAA
    }

    if (oldThread->space != NULL) {	// if this thread is a user program,
        oldThread->SaveUserState(); 	// save the user's CPU registers
		oldThread->space->SaveState();
    }
    
    oldThread->CheckOverflow();
    kernel->currentProcess = nextThread;  // switch to the next thread
    nextThread->setStatus(P_RUNNING);      // nextThread is now running
	nextThread->currentThread->setStatus(RUNNING);

    DEBUG(dbgThread, "Switching from: " << oldThread->getName() << " to: " << nextThread->getName());
	//cout << "151" << endl;
	//kernel->interrupt->SetLevel(IntOff);
    SWITCH(oldThread, nextThread->currentThread);//???
	//kernel->currentProcess->scheduler->Run(nextThread->currentThread,false);

	cout << "153" << endl;

	// we're back, running oldThread
	//kernel->interrupt->SetLevel(IntOn);//this is correct

	// interrupts are off when we return from switch!
	ASSERT(kernel->interrupt->getLevel() == IntOff);
	//cout << "scheduler 159" << endl;
	DEBUG(dbgThread, "Now in thread: " << oldThread->getName());

	CheckToBeDestroyedP();	
	//cout << "scheduler 163" << endl;

	if (oldThread->space != NULL) {	    // if there is an address space
		oldThread->RestoreUserState();     // to restore, do it.
		oldThread->space->RestoreState();
	}

	//kernel->interrupt->SetLevel(IntOn);//this is coorrect

}

//----------------------------------------------------------------------
// Scheduler::CheckToBeDestroyed
// 	If the old thread gave up the processor because it was finishing,
// 	we need to delete its carcass.  Note we cannot delete the thread
// 	before now (for example, in Thread::Finish()), because up to this
// 	point, we were still running on the old thread's stack!
//----------------------------------------------------------------------

void Scheduler::CheckToBeDestroyedP()//
{
    if (toBeDestroyedP != NULL) {
        delete toBeDestroyedP;
		toBeDestroyedP = NULL;
    }
}