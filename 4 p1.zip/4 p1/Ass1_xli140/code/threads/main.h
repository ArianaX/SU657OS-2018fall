// main.h 
//	This file defines the Nachos global variables
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#ifndef MAIN_H
#define MAIN_H

#include "copyright.h"
#include "debug.h"
#include "kernel.h"
//#include <unordered_map>

extern Kernel *kernel;
extern Debug *debug;
//extern unordered_map<Process*, List<Process*>> pList;
static int pid_base = 0;
static int quantumProcess = 0;

#endif // MAIN_H

