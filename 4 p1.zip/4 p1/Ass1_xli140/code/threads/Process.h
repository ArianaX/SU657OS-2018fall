#ifndef PROCESS_H
#define PROCESS_H

#include<iostream>
using namespace std;
#include "thread.h"
#include "../lib/list.h"
#include "../userprog/addrspace.h"
#include "../machine/machine.h"

#include "ProcessScheduler.h"

enum ProcessStatus { P_JUST_CREATED, P_RUNNING, P_READY, P_BLOCKED };

//now Process:
class Process {
private:
	int priotity;//priorities will be between 1 and 5, 5 being the highest.
	char* name;//string name,this is a name of process.
	ProcessStatus status;//this is a variable to record status of process
	int *stack; 	 	// Bottom of the stack 
	int pid;//this is an id of process
	//void StackAllocate(VoidFunctionPtr func, void *arg);
	int userRegisters[NumTotalRegs];	// user-level CPU register state
	int thread_nums = 0;//this records the number of thread within this process.

	void *machineState[MachineStateSize];  // all registers except for stackTop
	int *stackTop;			 // the current stack pointer
public:
	List<Process *> * PList = new List<Process*>();//this is list to store all child process of current father process
	List<Thread *> * threadList = new List<Thread*>();//this will store all threads here.
	Thread * currentThread;//this points to the current avalible thread that was selected by CPU
	ProcessScheduler* scheduler = new ProcessScheduler();//to manage threads, to control them when to run when to yield and when to terminate.

	Process(char* name, int priority, int thread_n);//this is my constructor to create process with its name,the priority and number of threads
	~Process();//delete pointer of process
	//Ariana
	void Yield();

	int getPriority() const;
	int getPid();
	void setStatus(ProcessStatus st) { status = st; }
	ProcessStatus getStatus() { return this->status; }
	char* getName() { return (name); }
	int getThreadNums() { return thread_nums; };
	void createChildProcess();

	void Print() { cout << name; }
	void Fork(VoidFunctionPtr func, void *arg); //Forks off a child process
	void Terminate();  		//Terminates the running process
	void Joint();//Makes a parent process block until all of the listed child processes have terminated. 

	void Sleep(bool finishing); // Put the thread to sleep and 
};

#endif