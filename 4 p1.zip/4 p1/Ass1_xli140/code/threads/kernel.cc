// kernel.cc 
//	Initialization and cleanup routines for the Nachos kernel.
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "debug.h"
//#include "main.h"
#include "kernel.h"
#include "sysdep.h"
#include "synch.h"
#include "synchlist.h"
#include "libtest.h"
#include "string.h"
#include "synchconsole.h"
#include "synchdisk.h"
#include "post.h"

//----------------------------------------------------------------------
// Kernel::Kernel
// 	Interpret command line arguments in order to determine flags 
//	for the initialization (see also comments in main.cc)  
//----------------------------------------------------------------------

Kernel::Kernel(int argc, char **argv)
{
	randomSlice = FALSE;
	debugUserProg = FALSE;
	consoleIn = NULL;          // default is stdin
	consoleOut = NULL;         // default is stdout
#ifndef FILESYS_STUB
	formatFlag = FALSE;
#endif
	reliability = 1;            // network reliability, default is 1.0
	hostName = 0;               // machine id, also UNIX socket name
								// 0 is the default machine id
	for (int i = 1; i < argc; i++) {
		if (strcmp(argv[i], "-rs") == 0) {
			ASSERT(i + 1 < argc);
			RandomInit(atoi(argv[i + 1]));// initialize pseudo-random
										  // number generator
			randomSlice = TRUE;
			i++;
		}
		else if (strcmp(argv[i], "-s") == 0) {
			debugUserProg = TRUE;
		}
		else if (strcmp(argv[i], "-ci") == 0) {
			ASSERT(i + 1 < argc);
			consoleIn = argv[i + 1];
			i++;
		}
		else if (strcmp(argv[i], "-co") == 0) {
			ASSERT(i + 1 < argc);
			consoleOut = argv[i + 1];
			i++;
#ifndef FILESYS_STUB
		}
		else if (strcmp(argv[i], "-f") == 0) {
			formatFlag = TRUE;
#endif
		}
		else if (strcmp(argv[i], "-n") == 0) {
			ASSERT(i + 1 < argc);   // next argument is float
			reliability = atof(argv[i + 1]);
			i++;
		}
		else if (strcmp(argv[i], "-m") == 0) {
			ASSERT(i + 1 < argc);   // next argument is int
			hostName = atoi(argv[i + 1]);
			i++;
		}
		else if (strcmp(argv[i], "-u") == 0) {
			cout << "Partial usage: nachos [-rs randomSeed]\n";
			cout << "Partial usage: nachos [-s]\n";
			cout << "Partial usage: nachos [-ci consoleIn] [-co consoleOut]\n";
#ifndef FILESYS_STUB
			cout << "Partial usage: nachos [-nf]\n";
#endif
			cout << "Partial usage: nachos [-n #] [-m #]\n";
		}
	}
}

//----------------------------------------------------------------------
// Kernel::Initialize
// 	Initialize Nachos global data structures.  Separate from the 
//	constructor because some of these refer to earlier initialized
//	data via the "kernel" global variable.
//----------------------------------------------------------------------

void
Kernel::Initialize()
{
	// We didn't explicitly allocate the current thread we are running in.
	// But if it ever tries to give up the CPU, we better have a Thread
	// object to save its state. 

	currentProcess = new Process("main", 0, 1);

	currentProcess->setStatus(P_RUNNING);
	currentProcess->currentThread = new Thread("initial");

	stats = new Statistics();		// collect statistics
	interrupt = new Interrupt;		// start up interrupt handling
	pscheduler = new Scheduler();	// initialize the ready queue

	alarm = new Alarm(randomSlice, quantumProcess);	// start up time slicing
	machine = new Machine(debugUserProg);
	synchConsoleIn = new SynchConsoleInput(consoleIn); // input from stdin
	synchConsoleOut = new SynchConsoleOutput(consoleOut); // output to stdout
	synchDisk = new SynchDisk();    //
#ifdef FILESYS_STUB
	fileSystem = new FileSystem();
#else
	fileSystem = new FileSystem(formatFlag);
#endif // FILESYS_STUB
	postOfficeIn = new PostOfficeInput(10);
	postOfficeOut = new PostOfficeOutput(reliability);

	interrupt->Enable();
}

//----------------------------------------------------------------------
// Kernel::~Kernel
// 	Nachos is halting.  De-allocate global data structures.
//----------------------------------------------------------------------

Kernel::~Kernel()
{
	delete stats;
	delete interrupt;
	delete pscheduler;
	delete alarm;
	delete machine;
	delete synchConsoleIn;
	delete synchConsoleOut;
	delete synchDisk;
	delete fileSystem;
	delete postOfficeIn;
	delete postOfficeOut;

	Exit(0);
}