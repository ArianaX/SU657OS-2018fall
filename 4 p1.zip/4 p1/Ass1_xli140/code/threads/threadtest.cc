#include "kernel.h"
#include "main.h"
#include <iostream>
using namespace std;

#include "Process.h"
//List<Process*>* allProcessL = new List<Process*>();

void SimpleProcess(int which)
{
    int num;
	cout << "***************** Process Process Process Process: " << kernel->currentProcess->getName()<<endl;
	kernel->currentProcess->Yield();
}


void ThreadTest()
{

	Process *p1 = new Process("A", 2, 2);
	//pList[p1] = new List<Process*>();
	p1->Fork((VoidFunctionPtr)SimpleProcess, (void *)p1->getThreadNums());//one time

	Process *p2 = new Process("B", 5, 2);
	//pList[p2]= new List<Process*>();
	p2->Fork((VoidFunctionPtr)SimpleProcess, (void *)p2->getThreadNums());//one time


	Process *p3 = new Process("C", 4, 4);
	//pList[p2]= new List<Process*>();
	p3->Fork((VoidFunctionPtr)SimpleProcess, (void *)p3->getThreadNums());//one time

	SimpleProcess(0);
	p1->createChildProcess();
	p1->Joint();

	p2->createChildProcess();
	p1->Joint();

	






}

