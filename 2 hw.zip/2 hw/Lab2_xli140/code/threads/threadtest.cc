#include "kernel.h"
#include "main.h"
#include "thread.h"
//#include<iostream>
//using namespace std;

#include "../hw2/Person.h"
#include "../lib/list.h"

//void SimpleThread(int which)
//{
//    int num;
//    
//    for (num = 0; num < 5; num++) {
//        printf("*** thread %d looped %d times\n", which, num);
//        kernel->currentThread->Yield();
//    }
//}

void PrintWaiting(Person p) {
	cout <<p.getSeq() << "\t" << p.getPri() << "\t" <<p.getTime() << "\t" <<p.getClothes()<<"\t"<< endl;
}
static int SeqCompare(Person p1, Person p2)
{
	if (p1.getSeq() < p2.getSeq())
		return -1;
	else if (p1.getSeq() > p2.getSeq())
		return 1;
	else
		return 0;
}
static int PriCompare(Person p1, Person p2)
{
	if (p1.getPri() < p2.getPri())
		return -1;
	else if (p1.getPri() > p2.getPri())
		return 1;
	else
		return 0;
}

void ThreadTest()
//int main()
{
	cout << "Introduction:" << endl;
	cout<<"Each person has his random laundry time within 1-10";
	cout << "Each person has his unique sequence number(1-20) and random prioritiy number(0-9) that 0 is the highest priority" << endl;
	cout << "Also each person has his random clothes number to clean in laundry room." << endl;
	cout << "-----------------------------------------------------------------------------" << endl;

	cout << "in the following part, i use seq# represent unique id." << endl;
	cout << "in entering and leaving part, the number represents the entering or leaving person." << endl;
	cout << "-----------------------------------------------------------------------------" << endl;
	List<Person>* queueL =new List<Person>();
	for (int i = 1; i <= 20; i++) {
		Person p=Person();
		p.setPri();
		p.setSeq(i);
		p.setTime();
		p.setClothes();
		queueL->Append(p);
	}
	//sort by sequence:
	SortedList<Person>* sortSeq=new SortedList<Person>(SeqCompare);
	//sort by priority:
	SortedList<Person>* sortPri =new SortedList<Person>(PriCompare);
	//using iterator
	ListIterator<Person> ip = ListIterator<Person>(queueL);
	while (!ip.IsDone()) {
		sortSeq->Insert(ip.Item());
		sortPri->Insert(ip.Item());

		ip.Next();
	}
	//print the waiting line:
	cout << "Order1: Now, we print the waiting line by sequence number:" << endl;
	cout << "Seq# \tPri# \tNeed time \tClothes \t" << endl;
	sortSeq->Apply(PrintWaiting);
	cout << "-----------------------------------------------------------------------------" << endl;
	cout << "Order2: Now, we print the waiting line by priority number:" << endl;
	cout << "Seq# \tPri# \tNeed time \tClothes \t" << endl;
	sortPri->Apply(PrintWaiting);

	cout << "-----------------------------------------------------------------------------" << endl;
	cout << "-----------------------------------------------------------------------------" << endl;
	cout << "-----------------------------------------------------------------------------" << endl;
	cout << "Simulation 2: I create 20 new person:" << endl;
	//create 20 new person:
	List<Person>* queueL2 = new List<Person>();
	for (int i = 1; i <= 20; i++) {
		Person p = Person();
		p.setPri();
		p.setSeq(i);
		p.setTime();
		p.setClothes();
		queueL2->Append(p);
	}
	//print the waiting line:
	cout << "Now, we print the waiting line by sequence number:" << endl;
	cout << "Seq# \tPri# \tNeed time \tClothes \t" << endl;
	queueL2->Apply(PrintWaiting);
	cout << "-----------------------------------------------------------------------------" << endl;

	cout << "Now\tSeq# \tPri# \tNeed time \tClothes \tEntering Seq# \tLeaving Seq# \t" << endl;
	ListIterator<Person> is1 = ListIterator<Person>(queueL2);
	int cur = 0;
	Person last = Person();
	while (!is1.IsDone()) {
		cout << cur << "\t" << is1.Item().getSeq() << "\t" << is1.Item().getPri() << "\t" << is1.Item().getTime() << "\t" << is1.Item().getClothes() << "\t" << is1.Item().getSeq() << "\t";
		if (last.empty())
			cout << "Null\t" << endl;
		else
			cout << last.getSeq() << "\t" << endl;

		last = is1.Item();
		cur = cur + is1.Item().getTime();
		is1.Next();

	}
	cout << "Total laundry time:" << cur << endl;















	////the second part:
	////now people start to use the laundry room by seq#: sortSeq
	//cout << "2, now people start to use the laundry room by seq#:" << endl;
	//


	////sorting by priority:
	//cout << endl;
	//cout << "-----------------------------------------------------------------------------" << endl;
	//
	////now people start to use the laundry room by pri#: sortPri
	//cout << "-----------------------------------------------------------------------------" << endl;
	//cout << "2, now people start to use the laundry room by pri#:" << endl;
	//cout << "Now\tSeq# \tPri# \tNeed time \tClothes \tEntering Seq# \tLeaving Seq# \t" << endl;
	//ListIterator<Person> is2 = ListIterator<Person>(sortPri);
	//cur = 0;
	//Person last2=Person();
	//while (!is2.IsDone()) {
	//	cout << cur << "\t" << is2.Item().getSeq() << "\t" << is2.Item().getPri() << "\t" << is2.Item().getTime() << "\t" << is2.Item().getClothes() << "\t" << is2.Item().getSeq() << "\t";
	//	if (last2.empty())
	//		cout << "Null\t" << endl;
	//	else
	//		cout << last2.getSeq() << "\t" << endl;

	//	last2 = is2.Item();
	//	cur = cur + is2.Item().getTime();
	//	is2.Next();
	//}
	//cout << "Total laundry time:" << cur << endl;


	

    /*Thread *t = new Thread("forked thread");
    t->Fork((VoidFunctionPtr) SimpleThread, (void *) 1);
    
    SimpleThread(0);*/
}
