#include <stdlib.h>

#include "Person.h"

Person::Person() {
	seq = 0;
	pri = 0;
	time = 0;
	clothes = 0;
}
Person::Person(int s, int p) {
	seq = s;
	pri = p;
}
bool Person::empty() {
	if (this->seq == 0)
		return true;
	else
		return false;
}

void Person::setPri() {
	pri = rand() % 10;
}

void Person::setSeq(int s) {
	seq = s;
}
void Person::setTime() {
	time = (rand() % 10)+1;
}
void Person::setClothes() {
	clothes= (rand() % 5) + 1;
}

int Person::getPri() const {
	return this->pri;
}
int Person::getSeq() const {
	return this->seq;
}
int Person::getTime() const {
	return this->time;
}
int Person::getClothes() const{
	return this->clothes;
}
bool Person::operator == ( Person p) const {
	if (this->pri == p.getPri() && this->seq == p.getSeq() && this->time == p.getTime())
		return true;
	else 
		return false;
}