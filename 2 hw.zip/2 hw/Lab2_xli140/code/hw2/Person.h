#include<iostream>
using namespace std;

//each person has his laundry time within 1-10;
class Person {// each person has his unique sequence number(1-20) and prioritiy number(0-9)
private:
	int seq;
	int pri;
	int time;
	int clothes;
public:
	Person();
	Person(int s, int p);//this is constructor

	bool empty();

	void setPri();//this function is going to set the random priority.

	void setSeq(int s);

	void setTime();

	void setClothes();

	int getPri()const;//this function is going to get the random priority.

	int getSeq()const;

	int getTime() const;

	int getClothes() const;

	bool operator == ( Person p)const;
};